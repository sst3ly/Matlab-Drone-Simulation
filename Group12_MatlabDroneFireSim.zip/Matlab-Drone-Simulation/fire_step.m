function [new_fire] = fire_step(tiles, params)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
arguments (Input)
    tiles
    params
end

arguments (Output)
    new_fire
end

% ------- Decay -------
% 
for x = 1 : length(tiles)
    for y = 1 : length(tiles)
        if tiles(x,y) > 0
        tiles(x,y) = tiles(x,y) - params.decay_rate;
            tiles(x,y) = max(0,tiles(x,y));
        end
    end
end

new_fire = tiles;

% ------- Spread -------
% 
for x = 1 : length(tiles)
    for y = 1 : length(tiles)
        if tiles(x,y) > params.strength_threshold
            if x > 1
                new_fire(x-1,y) = tiles(x-1,y) + params.spread_rate;
                new_fire(x-1,y) = min(1,new_fire(x-1,y));
            end
            if x < params.grid_size - 1
                new_fire(x+1,y) = tiles(x+1,y) + params.spread_rate;
                new_fire(x+1,y) = min(1,new_fire(x+1,y));
            end
            if y > 1
                new_fire(x,y-1) = tiles(x,y-1) + params.spread_rate;
                new_fire(x,y-1) = min(1,new_fire(x,y-1));
            end
            if y < params.grid_size - 1
                new_fire(x,y+1) = tiles(x,y+1) + params.spread_rate;
                new_fire(x,y+1) = min(1,new_fire(x,y+1));
% ------- Diagonal Spread -------
            if rand > params.diag_prob && x > 1 && y > 1
                new_fire(x-1,y-1) = tiles(x-1,y-1) + params.spread_rate;
                new_fire(x-1,y-1) = min(1,new_fire(x-1,y-1));
            end
            if rand > params.diag_prob && x < params.grid_size - 1 && y > 1
                new_fire(x+1,y-1) = tiles(x+1,y-1) + params.spread_rate;
                new_fire(x+1,y-1) = min(1,new_fire(x+1,y-1));
            end
            if rand > params.diag_prob && x > 1 && y < params.grid_size - 1
                new_fire(x-1,y+1) = tiles(x-1,y+1) + params.spread_rate;
                new_fire(x-1,y+1) = min(1,new_fire(x-1,y+1));
            end
            if rand > params.diag_prob && x < params.grid_size && y < params.grid_size
                new_fire(x+1,y+1) = tiles(x+1,y+1) + params.spread_rate;
                new_fire(x+1,y+1) = min(1,new_fire(x+1,y+1));
            end
            end
        end
    end
end
        